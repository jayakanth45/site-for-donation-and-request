<?php
// Start session
session_start();

// Check if a type is set in the URL (for "Donate" or "Request")
$action_type = isset($_GET['type']) ? $_GET['type'] : '';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database connection file
include('test_db_connection.php');

// Check if the user is already logged in
if (isset($_SESSION['usertype'])) {
    // Redirect to the respective dashboard
    if ($_SESSION['usertype'] === 'company') {
        header("Location: company_dashboard.php");
        exit(); // Stop further execution
    } elseif ($_SESSION['usertype'] === 'school') {
        header("Location: school_dashboard.php");
        exit(); // Stop further execution
    }
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the email and password from the form
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Sanitize input to prevent SQL injection
    if ($conn) {
        $email = mysqli_real_escape_string($conn, $email);
        $password = mysqli_real_escape_string($conn, $password);

        // Query the database for the user
        $query = "SELECT * FROM users WHERE email='$email'";
        $result = mysqli_query($conn, $query);

        // Check if user exists
        if (mysqli_num_rows($result) == 1) {
            // Fetch user details
            $row = mysqli_fetch_assoc($result);

            // Compare passwords (assuming plain text for now)
            if ($row['password'] === $password) {
                // Set session variables
                $_SESSION['email'] = $email;
                $_SESSION['usertype'] = $row['userType'];

                // Redirect based on user type
                if ($row['userType'] === 'company') {
                    header("Location: company_dashboard.php");
                } elseif ($row['userType'] === 'school') {
                    header("Location: school_dashboard.php");
                }
                exit(); // Stop further execution
            } else {
                $error_message = "Incorrect password!";
            }
        } else {
            $error_message = "Invalid email or password!";
        }
    } else {
        $error_message = "Database connection failed!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        /* Basic styles to improve the appearance */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 300px; /* Set a fixed width for the container */
            text-align: center;
        }
        input {
            display: block;
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 10px 20px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .error {
            color: red;
            font-size: 14px;
        }
        .signup-link {
            margin-top: 15px;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Login</h2>

        <?php
        // Display a message based on the action type
        if ($action_type === 'donate') {
            echo "<p>You are here to donate. Please log in.</p>";
        } elseif ($action_type === 'request') {
            echo "<p>You are here to request a donation. Please log in.</p>";
        }

        // Display error message if set
        if (isset($error_message)) {
            echo "<p class='error'>$error_message</p>";
        }
        ?>

        <!-- Login form -->
        <form action="login.php" method="POST">
            <input type="email" name="email" placeholder="Enter your email" required>
            <input type="password" name="password" placeholder="Enter your password" required>
            <button type="submit">Login</button>
        </form>

        <!-- Sign up link -->
        <div class="signup-link">
            <p>Don't have an account? <a href="signup.php">Sign Up</a></p>
        </div>
    </div>

</body>
</html>

