<?php
// Start session
session_start();

// Check if the user is logged in and is a company
if (!isset($_SESSION['usertype']) || $_SESSION['usertype'] !== 'company') {
    header("Location: login.php");
    exit();
}

// Include database connection file
include('test_db_connection.php');

// Fetch available requests from the database (available_requests table)
$query = "SELECT * FROM available_requests";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 500px;
            text-align: center;
        }
        h2 {
            margin-bottom: 20px;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
            text-decoration: none;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Company Dashboard</h2>

        <p>Welcome to the company dashboard. You can donate items to schools requesting for donations.</p>

        <!-- Display the requests from schools -->
        <h3>Available Requests</h3>
        <table>
            <tr>
                <th>School Name</th>
                <th>Item</th>
                <th>Quantity</th>
            </tr>
            <?php
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>{$row['school_name']}</td>";
                echo "<td>{$row['item']}</td>";
                echo "<td>{$row['quantity']}</td>";
                echo "</tr>";
            }
            ?>
        </table>

        <a href="process_donation.php" class="btn">Donate to Site</a>
        <a href="process_donation.php?to=school" class="btn">Donate to Specific School</a>
        <br><br>
        <a href="logout.php" class="btn">Logout</a>
    </div>

</body>
</html>
