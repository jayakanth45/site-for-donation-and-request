<?php
// Start session
session_start();

// Check if the user is logged in and is a school
if (!isset($_SESSION['usertype']) || $_SESSION['usertype'] !== 'school') {
    header("Location: login.php");
    exit();
}

// Include database connection file
include('test_db_connection.php');

// Fetch available donations from the available_donations table
$query = "SELECT * FROM available_donations";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 500px;
            text-align: center;
        }
        h2 {
            margin-bottom: 20px;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
            text-decoration: none;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>School Dashboard</h2>

        <p>Welcome to the school dashboard. You can request donations from the site or take donations from a specific company.</p>

        <!-- Display the available donations -->
        <h3>Available Donations</h3>
        <table>
            <tr>
                <th>Company Name</th>
                <th>Item</th>
                <th>Quantity</th>
            </tr>
            <?php
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>{$row['company_name']}</td>";
                echo "<td>{$row['item']}</td>";
                echo "<td>{$row['quantity']}</td>";
                echo "</tr>";
            }
            ?>
        </table>

        <!-- Action buttons -->
        <a href="process_request.php" class="btn">Request from Site</a>
        <a href="process_request.php?from=company" class="btn">Take from Specific Company</a>
        <br><br>
        <a href="logout.php" class="btn">Logout</a>
    </div>

</body>
</html>

