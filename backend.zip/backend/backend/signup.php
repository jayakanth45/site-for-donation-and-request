<?php
// Start session
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database connection file
include('test_db_connection.php');

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the submitted form data
    $email = $_POST['email'];
    $password = $_POST['password'];
    $address = $_POST['address'];
    $zip = $_POST['zip'];
    $mobile = $_POST['mobile'];
    $usertype = $_POST['usertype']; // 'company' or 'school'

    // Sanitize input to prevent SQL injection
    if ($conn) {
        $email = mysqli_real_escape_string($conn, $email);
        $password = mysqli_real_escape_string($conn, $password);
        $address = mysqli_real_escape_string($conn, $address);
        $zip = mysqli_real_escape_string($conn, $zip);
        $mobile = mysqli_real_escape_string($conn, $mobile);
        $usertype = mysqli_real_escape_string($conn, $usertype);

        // Check if user already exists
        $check_user_query = "SELECT * FROM users WHERE email='$email'";
        $result = mysqli_query($conn, $check_user_query);
        if (mysqli_num_rows($result) > 0) {
            $error_message = "You are already a user, please login!";
        } else {
            // Insert the new user into the database
            $insert_query = "INSERT INTO users (email, password, address, zip, mobile, userType) 
                             VALUES ('$email', '$password', '$address', '$zip', '$mobile', '$usertype')";
            if (mysqli_query($conn, $insert_query)) {
                $success_message = "Signup successful! Please login.";
            } else {
                $error_message = "Signup failed. Please try again.";
            }
        }
    } else {
        $error_message = "Database connection failed!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Page</title>
    <style>
        /* Reuse the same styles from login page */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
        }
        input, select {
            display: block;
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
        .error, .success {
            font-size: 14px;
        }
        .error {
            color: red;
        }
        .success {
            color: green;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Sign Up</h2>

        <!-- Display error or success messages -->
        <?php if (isset($error_message)) { ?>
            <p class="error"><?php echo $error_message; ?></p>
        <?php } elseif (isset($success_message)) { ?>
            <p class="success"><?php echo $success_message; ?></p>
        <?php } ?>

        <!-- Signup form -->
        <form action="signup.php" method="POST">
            <input type="email" name="email" placeholder="Enter email" required>
            <input type="password" name="password" placeholder="Enter password" required>
            <input type="text" name="address" placeholder="Enter address" required>
            <input type="text" name="zip" placeholder="Enter zip code" required>
            <input type="text" name="mobile" placeholder="Enter mobile number" required>
            <select name="usertype" required>
                <option value="">Select User Type</option>
                <option value="company">Company</option>
                <option value="school">School</option>
            </select>
            <button type="submit">Sign Up</button>
        </form>

        <p>Already have an account? <a href="login.php">Login</a></p> <!-- Link to login page -->
    </div>

</body>
</html>
