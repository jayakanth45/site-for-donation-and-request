<?php
// Database configuration
$host = "localhost";
$user = "root"; // Your MySQL username
$password = ""; // Your MySQL password (leave blank if you haven't set one)
$dbname = "techwithtech"; // Your database name

// Create connection
$conn = mysqli_connect($host, $user, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
