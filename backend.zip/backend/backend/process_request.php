<?php
// Start session
session_start();

// Include database connection file
include('test_db_connection.php');

// Check if the user is logged in and is a school
if (!isset($_SESSION['usertype']) || $_SESSION['usertype'] !== 'school') {
    header("Location: login.php");
    exit();
}

// Handle form submission for requesting donations
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $school_name = $_POST['school_name']; // Now mandatory for requests from the site
    $item = $_POST['item'];
    $quantity = $_POST['quantity'];

    // Check if it's a request from a specific company
    if (isset($_POST['company_name']) && !empty($_POST['company_name'])) {
        $company_name = $_POST['company_name'];

        // Check if the company exists in the available_donations table
        $check_company_query = "SELECT * FROM available_donations WHERE company_name='$company_name'";
        $result = mysqli_query($conn, $check_company_query);

        if (mysqli_num_rows($result) > 0) {
            // Remove company donation and confirm the request
            $delete_donation_query = "DELETE FROM available_donations WHERE company_name='$company_name'";
            mysqli_query($conn, $delete_donation_query);
            $success_message = "Donation received from $company_name!";
        } else {
            $error_message = "Company not found or no donations available!";
        }
    } else {
        // Insert request into available_requests table for general site requests
        $insert_query = "INSERT INTO available_requests (school_name, item, quantity) 
                         VALUES ('$school_name', '$item', '$quantity')";
        if (mysqli_query($conn, $insert_query)) {
            $success_message = "Request submitted successfully!";
        } else {
            $error_message = "Failed to submit request. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Process Request</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: center;
        }
        input {
            display: block;
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .error, .success {
            font-size: 14px;
        }
        .error {
            color: red;
        }
        .success {
            color: green;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Request Donations</h2>

        <!-- Display error or success messages -->
        <?php if (isset($error_message)) { ?>
            <p class="error"><?php echo $error_message; ?></p>
        <?php } elseif (isset($success_message)) { ?>
            <p class="success"><?php echo $success_message; ?></p>
        <?php } ?>

        <!-- Request form -->
        <form action="process_request.php" method="POST">
            <!-- School name is now required for requests -->
            <input type="text" name="school_name" placeholder="Enter school name" required>
            <input type="text" name="item" placeholder="Enter item needed" required>
            <input type="number" name="quantity" placeholder="Enter quantity" required>

            <!-- If requesting from a specific company -->
            <?php if (isset($_GET['from']) && $_GET['from'] === 'company') { ?>
                <input type="text" name="company_name" placeholder="Enter company name" required>
            <?php } ?>

            <button type="submit">Submit Request</button>
        </form>

        <br><br>
        <a href="school_dashboard.php">Back to Dashboard</a>
    </div>

</body>
</html>
