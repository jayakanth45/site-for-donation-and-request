<?php
// Start session
session_start();

// Include database connection file
include('test_db_connection.php');

// Check if the user is logged in and is a company
if (!isset($_SESSION['usertype']) || $_SESSION['usertype'] !== 'company') {
    header("Location: login.php");
    exit();
}

// Handle form submission for donating
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $company_name = $_POST['company_name']; // Now mandatory for both donation types
    $item = $_POST['item'];
    $quantity = $_POST['quantity'];

    // Check if the donation is to a specific school or general site donation
    if (isset($_POST['school_name']) && !empty($_POST['school_name'])) {
        $school_name = $_POST['school_name'];

        // Check if the school exists in the available_requests table
        $check_school_query = "SELECT * FROM available_requests WHERE school_name='$school_name'";
        $result = mysqli_query($conn, $check_school_query);

        if (mysqli_num_rows($result) > 0) {
            // Remove school request and confirm donation
            $delete_request_query = "DELETE FROM available_requests WHERE school_name='$school_name'";
            mysqli_query($conn, $delete_request_query);
            $success_message = "Thanks for your donation to $school_name!";
        } else {
            $error_message = "School not found!";
        }
    } else {
        // Insert general donation into available_donations table
        $insert_query = "INSERT INTO available_donations (company_name, item, quantity) 
                         VALUES ('$company_name', '$item', '$quantity')";
        if (mysqli_query($conn, $insert_query)) {
            $success_message = "Thanks for your donation!";
        } else {
            $error_message = "Failed to donate. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Process Donation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: center;
        }
        input {
            display: block;
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
        .error, .success {
            font-size: 14px;
        }
        .error {
            color: red;
        }
        .success {
            color: green;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Donate Items</h2>

        <!-- Display error or success messages -->
        <?php if (isset($error_message)) { ?>
            <p class="error"><?php echo $error_message; ?></p>
        <?php } elseif (isset($success_message)) { ?>
            <p class="success"><?php echo $success_message; ?></p>
        <?php } ?>

        <!-- Donation form -->
        <form action="process_donation.php" method="POST">
            <input type="text" name="company_name" placeholder="Enter company name" required>
            <input type="text" name="item" placeholder="Enter item to donate" required>
            <input type="number" name="quantity" placeholder="Enter quantity" required>

            <!-- If donating to a specific school -->
            <?php if (isset($_GET['to']) && $_GET['to'] === 'school') { ?>
                <input type="text" name="school_name" placeholder="Enter school name" required>
            <?php } ?>

            <button type="submit">Donate</button>
        </form>

        <br><br>
        <a href="company_dashboard.php">Back to Dashboard</a>
    </div>

</body>
</html>

